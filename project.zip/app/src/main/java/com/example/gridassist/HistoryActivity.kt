package com.example.gridassist

import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : ComponentActivity() {

    private lateinit var list: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: String, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(Color.parseColor(color))
    }

    private fun text(t: String, size: Float, color: String, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(Color.parseColor(color))
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(label: String, color: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(color, 14)
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(button("← Kembali", "#475569") { finish() })
        top.addView(
            text("  Riwayat Gemini", 22f, "#FFFFFF", true).apply { setPadding(dp(8), dp(8), 0, 0) }
        )
        root.addView(top)

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(list)

        root.addView(button("Hapus semua riwayat", "#DC2626") {
            History.clear(this)
            render()
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F172A"))
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        list.removeAllViews()
        val items = History.load(this).reversed()
        if (items.isEmpty()) {
            list.addView(
                text(
                    "Belum ada riwayat. Tap bubble di game, nanti setiap jawaban Gemini tercatat di sini.",
                    14f, "#94A3B8"
                ).apply { setPadding(0, dp(16), 0, dp(16)) }
            )
            return
        }
        items.forEach { list.addView(card(it)) }
    }

    private fun statusColor(s: String) = when {
        s == "Dijalankan" || s == "Disarankan" -> "#4ADE80"
        s == "Tidak ada langkah" -> "#FBBF24"
        else -> "#F87171"
    }

    private fun card(e: History.Entry): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded("#1E293B", 16)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
        }
        val time = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()).format(Date(e.ts))
        val modeLabel = if (e.mode == Prefs.MODE_AUTO) "⚡ Auto" else "💡 Saran"
        c.addView(text("$time  •  $modeLabel", 12f, "#94A3B8"))
        c.addView(text(e.status, 15f, statusColor(e.status), true).apply { setPadding(0, dp(4), 0, 0) })

        if (e.explanation.isNotEmpty()) {
            c.addView(text(e.explanation, 15f, "#F1F5F9").apply { setPadding(0, dp(6), 0, 0) })
        }
        if (e.moves.isNotEmpty()) {
            c.addView(
                text(e.moves, 13f, "#CBD5E1").apply {
                    typeface = Typeface.MONOSPACE
                    setPadding(0, dp(6), 0, 0)
                }
            )
            c.addView(text("(koordinat 0–1000 dari kiri-atas layar)", 11f, "#64748B"))
        }

        e.image?.let { name ->
            val f = File(filesDir, name)
            if (f.exists()) {
                val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                val bmp = BitmapFactory.decodeFile(f.path, opts)
                if (bmp != null) {
                    c.addView(ImageView(this).apply {
                        setImageBitmap(bmp)
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        setBackgroundColor(Color.parseColor("#0F172A"))
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, dp(240)
                        ).apply { topMargin = dp(10) }
                    })
                }
            }
        }

        val rawView = text(e.raw.ifEmpty { "(tidak ada balasan mentah)" }, 11f, "#94A3B8").apply {
            visibility = View.GONE
            setPadding(0, dp(8), 0, 0)
            setTextIsSelectable(true)
        }
        c.addView(text("Ketuk kartu untuk balasan mentah Gemini", 11f, "#64748B").apply {
            setPadding(0, dp(8), 0, 0)
        })
        c.addView(rawView)
        c.setOnClickListener {
            rawView.visibility = if (rawView.visibility == View.GONE) View.VISIBLE else View.GONE
        }
        return c
    }
}
