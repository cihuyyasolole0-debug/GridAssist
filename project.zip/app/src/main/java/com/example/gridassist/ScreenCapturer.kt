package com.example.gridassist

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.Base64
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream

/**
 * One VirtualDisplay for the whole session (Android 14+ forbids creating several per
 * projection). The newest frame is kept so a static screen can still be captured.
 */
class ScreenCapturer(
    projection: MediaProjection,
    width: Int,
    height: Int,
    dpi: Int
) {
    private val thread = HandlerThread("gridassist-capture").apply { start() }
    private val handler = Handler(thread.looper)
    private val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
    private val lock = Any()
    private var latest: Image? = null
    private val display: VirtualDisplay

    init {
        reader.setOnImageAvailableListener({ r ->
            val img = try { r.acquireLatestImage() } catch (e: IllegalStateException) { null }
            if (img != null) {
                synchronized(lock) {
                    latest?.close()
                    latest = img
                }
            }
        }, handler)
        display = projection.createVirtualDisplay(
            "GridAssistCapture", width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )
    }

    /** Returns the current screen as a downscaled JPEG, Base64 encoded (no line wraps). */
    suspend fun captureJpegBase64(maxSide: Int = 1280): String? {
        var waited = 0
        while (synchronized(lock) { latest == null } && waited < 3000) {
            delay(100)
            waited += 100
        }
        val bmp = synchronized(lock) { latest?.let { toBitmap(it) } } ?: return null
        val scale = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
        val out = if (scale < 1f) {
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        } else bmp
        val bos = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 80, bos)
        if (out !== bmp) out.recycle()
        bmp.recycle()
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val buf = plane.buffer
        buf.rewind()
        val rowPixels = plane.rowStride / plane.pixelStride
        val padded = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buf)
        return if (rowPixels == img.width) padded
        else Bitmap.createBitmap(padded, 0, 0, img.width, img.height).also { padded.recycle() }
    }

    fun release() {
        display.release()
        reader.setOnImageAvailableListener(null, null)
        synchronized(lock) { latest?.close(); latest = null }
        reader.close()
        thread.quitSafely()
    }
}
