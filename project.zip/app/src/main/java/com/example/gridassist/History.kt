package com.example.gridassist

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object History {
    private const val FILE = "history.json"
    private const val MAX = 30

    data class Entry(
        val ts: Long,
        val mode: String,
        val status: String,
        val explanation: String,
        val moves: String,
        val image: String?,
        val raw: String
    )

    @Synchronized
    fun load(c: Context): MutableList<Entry> {
        val f = File(c.filesDir, FILE)
        if (!f.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(f.readText())
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Entry(
                    o.getLong("ts"),
                    o.optString("mode"),
                    o.optString("status"),
                    o.optString("explanation"),
                    o.optString("moves"),
                    o.optString("image").ifEmpty { null },
                    o.optString("raw")
                )
            }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    @Synchronized
    fun add(c: Context, e: Entry, jpeg: ByteArray?) {
        val list = load(c)
        val img = if (jpeg != null) {
            val name = "cap_${e.ts}.jpg"
            File(c.filesDir, name).writeBytes(jpeg)
            name
        } else null
        list.add(e.copy(image = img))
        while (list.size > MAX) {
            val old = list.removeAt(0)
            old.image?.let { File(c.filesDir, it).delete() }
        }
        save(c, list)
    }

    @Synchronized
    fun clear(c: Context) {
        load(c).forEach { e -> e.image?.let { File(c.filesDir, it).delete() } }
        File(c.filesDir, FILE).delete()
    }

    private fun save(c: Context, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("ts", it.ts)
                    .put("mode", it.mode)
                    .put("status", it.status)
                    .put("explanation", it.explanation)
                    .put("moves", it.moves)
                    .put("image", it.image ?: "")
                    .put("raw", it.raw)
            )
        }
        File(c.filesDir, FILE).writeText(arr.toString())
    }
}
