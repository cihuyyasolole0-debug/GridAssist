package com.example.gridassist

import android.content.Context

object Prefs {
    const val DEFAULT_GOAL =
        "This is an offline single-player chess game against the computer. " +
            "I play the pieces at the bottom of the screen. Find the single best legal move for me."

    private fun sp(c: Context) = c.getSharedPreferences("gridassist", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("api_key", "") ?: ""
    fun goal(c: Context): String = sp(c).getString("goal", DEFAULT_GOAL) ?: DEFAULT_GOAL

    fun save(c: Context, key: String, goal: String) {
        sp(c).edit()
            .putString("api_key", key.trim())
            .putString("goal", goal.trim().ifEmpty { DEFAULT_GOAL })
            .apply()
    }
}
