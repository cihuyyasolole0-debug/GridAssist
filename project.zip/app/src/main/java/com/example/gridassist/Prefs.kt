package com.example.gridassist

import android.content.Context

object Prefs {
    const val MODE_SUGGEST = "suggest"
    const val MODE_AUTO = "auto"

    const val DEFAULT_GOAL =
        "Layar menunjukkan game catur single-player melawan komputer (bot), papan 8x8. " +
            "Aku main bidak yang ada di bagian bawah layar. Cari satu langkah legal terbaik untukku."

    private fun sp(c: Context) = c.getSharedPreferences("gridassist", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString("api_key", "") ?: ""
    fun goal(c: Context): String = sp(c).getString("goal", DEFAULT_GOAL) ?: DEFAULT_GOAL
    fun mode(c: Context): String = sp(c).getString("mode", MODE_AUTO) ?: MODE_AUTO
    fun setMode(c: Context, m: String) { sp(c).edit().putString("mode", m).apply() }

    fun save(c: Context, key: String, goal: String) {
        sp(c).edit()
            .putString("api_key", key.trim())
            .putString("goal", goal.trim().ifEmpty { DEFAULT_GOAL })
            .apply()
    }
}
