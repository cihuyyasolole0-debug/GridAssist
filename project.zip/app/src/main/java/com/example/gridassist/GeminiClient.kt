package com.example.gridassist

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {

    // Change this if Google retires the model. See ai.google.dev/gemini-api/docs/models
    const val MODEL = "gemini-2.5-flash"

    @Volatile var lastRaw: String = ""

    /** type = "tap" or "swipe". Coordinates are normalized 0..1000 over the screenshot. */
    data class Action(val type: String, val x: Int, val y: Int, val x2: Int, val y2: Int)
    data class Plan(val explanation: String, val actions: List<Action>)

    private val SYSTEM = """
        You are a vision assistant for a user with a severe motor impairment who cannot tap the screen.
        The screenshot shows an OFFLINE, single-player puzzle or board game played against the computer.
        Identify the grid, decide the single best next move for the user's goal, and output the touches
        needed to perform it.
        Rules:
        - Coordinates are integers normalized to 0-1000 over the image: x=0 is the left edge, x=1000 the
          right edge, y=0 the top edge, y=1000 the bottom edge. Point at the CENTER of the target cell.
        - For chess-like games a move is two taps: the source square first, then the destination square.
        - Only propose legal moves.
        - If a board or grid game is visible, ALWAYS choose a move even if you are not fully sure.
          Return an empty actions array only when no game board is visible at all or the game is over.
        - Never return more than 4 actions. Start "explanation" with what you see on screen, max 25 words.
    """.trimIndent()

    private val SCHEMA = JSONObject(
        """
        {"type":"OBJECT","properties":{
          "explanation":{"type":"STRING"},
          "actions":{"type":"ARRAY","items":{"type":"OBJECT","properties":{
            "type":{"type":"STRING","enum":["tap","swipe"]},
            "x":{"type":"INTEGER"},"y":{"type":"INTEGER"},
            "x2":{"type":"INTEGER"},"y2":{"type":"INTEGER"}},
            "required":["type","x","y"]}}},
          "required":["explanation","actions"]}
        """.trimIndent()
    )

    suspend fun analyze(apiKey: String, jpegBase64: String, goal: String): Plan =
        withContext(Dispatchers.IO) {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
                .put(
                    "contents", JSONArray().put(
                        JSONObject().put("role", "user").put(
                            "parts", JSONArray()
                                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", jpegBase64)))
                                .put(JSONObject().put("text", "User goal: $goal"))
                        )
                    )
                )
                .put(
                    "generationConfig", JSONObject()
                        .put("temperature", 0.2)
                        .put("responseMimeType", "application/json")
                        .put("responseSchema", SCHEMA)
                )

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 90_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", apiKey)
            }
            try {
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                lastRaw = "HTTP $code\n" + text.take(4000)
                if (code !in 200..299) throw IOException("Gemini HTTP $code: ${text.take(200)}")
                parse(text)
            } finally {
                conn.disconnect()
            }
        }

    private fun parse(raw: String): Plan {
        val cands = JSONObject(raw).optJSONArray("candidates")
        if (cands == null || cands.length() == 0) throw IOException("Gemini returned no answer (blocked or empty)")
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw IOException("Gemini returned no content")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        val clean = sb.toString().trim().removePrefix("```json").removeSuffix("```").trim()
        val obj = JSONObject(clean)
        val arr = obj.optJSONArray("actions") ?: JSONArray()
        val actions = (0 until arr.length()).map {
            val a = arr.getJSONObject(it)
            Action(
                a.optString("type", "tap"),
                a.optInt("x"), a.optInt("y"), a.optInt("x2"), a.optInt("y2")
            )
        }
        return Plan(obj.optString("explanation"), actions)
    }
}
