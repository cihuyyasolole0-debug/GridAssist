package com.example.gridassist

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var overlayView: TextView
    private lateinit var a11yView: TextView
    private lateinit var keyField: EditText
    private lateinit var goalField: EditText
    private lateinit var modeTile: LinearLayout

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, FloatingService::class.java)
                    .putExtra(FloatingService.EXTRA_CODE, r.resultCode)
                    .putExtra(FloatingService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                Toast.makeText(this, "Bubble aktif. Buka game kamu.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Izin screen capture ditolak", Toast.LENGTH_LONG).show()
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: String, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(Color.parseColor(color))
    }

    private fun title(t: String, size: Float = 16f, color: String = "#E2E8F0") =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(Color.parseColor(color))
            setPadding(0, dp(14), 0, dp(4))
        }

    private fun styleField(e: EditText) {
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#64748B"))
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        e.background = rounded("#1E293B", 12)
    }

    private fun button(label: String, color: String = "#2563EB", onClick: () -> Unit) =
        Button(this).apply {
            text = label
            textSize = 17f
            isAllCaps = false
            setTextColor(Color.WHITE)
            minHeight = dp(60)
            background = rounded(color, 16)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        }

    /** Square-ish menu tile: child 0 = emoji, child 1 = label. */
    private fun tile(emoji: String, label: String, onClick: () -> Unit): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(20), dp(10), dp(20))
        t.background = rounded("#1E293B", 20)
        t.addView(TextView(this).apply {
            text = emoji
            textSize = 36f
            gravity = Gravity.CENTER
        })
        t.addView(TextView(this).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#E2E8F0"))
            setPadding(0, dp(8), 0, 0)
        })
        t.setOnClickListener { onClick() }
        t.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            .apply { setMargins(dp(5), dp(8), dp(5), dp(8)) }
        return t
    }

    private fun updateModeTile() {
        val auto = Prefs.mode(this) == Prefs.MODE_AUTO
        (modeTile.getChildAt(0) as TextView).text = if (auto) "⚡" else "💡"
        (modeTile.getChildAt(1) as TextView).text =
            if (auto) "Mode: AUTO\nlangsung bergerak\n(ketuk untuk ganti)"
            else "Mode: SARAN\npetunjuk saja\n(ketuk untuk ganti)"
        modeTile.background = rounded(if (auto) "#9A3412" else "#1E3A8A", 20)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(28))
        }
        col.addView(title("GridAssist", 30f, "#FFFFFF"))
        col.addView(title("Asisten tap otomatis untuk game puzzle offline", 14f, "#94A3B8"))

        overlayView = title("", 16f)
        a11yView = title("", 16f)
        col.addView(overlayView)
        col.addView(a11yView)

        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tiles.addView(tile("📜", "Riwayat\njawaban Gemini") {
            startActivity(Intent(this, HistoryActivity::class.java))
        })
        modeTile = tile("⚡", "") {
            val next = if (Prefs.mode(this) == Prefs.MODE_AUTO) Prefs.MODE_SUGGEST else Prefs.MODE_AUTO
            Prefs.setMode(this, next)
            updateModeTile()
            // refresh bubble + notification if the service is already running
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_REFRESH))
        }
        tiles.addView(modeTile)
        col.addView(tiles)
        updateModeTile()

        col.addView(title("Gemini API key"))
        keyField = EditText(this).apply {
            hint = "Tempel API key di sini"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.apiKey(this@MainActivity))
        }
        styleField(keyField)
        col.addView(keyField)

        col.addView(title("Tujuan / instruksi untuk AI"))
        goalField = EditText(this).apply {
            hint = "Apa yang harus dibantu?"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(Prefs.goal(this@MainActivity))
        }
        styleField(goalField)
        col.addView(goalField)

        col.addView(button("1. Izinkan bubble melayang") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(button("2. Buka pengaturan aksesibilitas") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("3. Mulai asisten", "#16A34A") { start() })
        col.addView(button("Stop asisten", "#DC2626") {
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_STOP))
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F172A"))
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        val overlay = Settings.canDrawOverlays(this)
        val a11y = GestureService.instance != null
        overlayView.text = if (overlay) "✅ Izin bubble: OK" else "❌ Izin bubble: belum aktif"
        overlayView.setTextColor(Color.parseColor(if (overlay) "#4ADE80" else "#F87171"))
        a11yView.text = if (a11y) "✅ Aksesibilitas: ON" else "❌ Aksesibilitas: OFF (wajib untuk mode Auto)"
        a11yView.setTextColor(Color.parseColor(if (a11y) "#4ADE80" else "#F87171"))
        updateModeTile()
    }

    private fun start() {
        Prefs.save(this, keyField.text.toString(), goalField.text.toString())
        val auto = Prefs.mode(this) == Prefs.MODE_AUTO
        when {
            Prefs.apiKey(this).isEmpty() -> toast("Isi dulu Gemini API key")
            !Settings.canDrawOverlays(this) -> toast("Langkah 1 dulu: izinkan bubble")
            auto && GestureService.instance == null ->
                toast("Mode Auto butuh Langkah 2: nyalakan aksesibilitas GridAssist (atau pilih mode Saran)")
            else -> {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
