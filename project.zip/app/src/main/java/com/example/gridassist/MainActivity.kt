package com.example.gridassist

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var keyField: EditText
    private lateinit var goalField: EditText

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, FloatingService::class.java)
                    .putExtra(FloatingService.EXTRA_CODE, r.resultCode)
                    .putExtra(FloatingService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, i)
                Toast.makeText(this, "Bubble started. Switch to your game.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Screen capture was not allowed", Toast.LENGTH_LONG).show()
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 18f
        minHeight = dp(64)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        col.addView(TextView(this).apply { text = "GridAssist"; textSize = 28f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, dp(8), 0, dp(8)) }
        col.addView(status)

        keyField = EditText(this).apply {
            hint = "Gemini API key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.apiKey(this@MainActivity))
        }
        col.addView(keyField)

        goalField = EditText(this).apply {
            hint = "What should the assistant do?"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(Prefs.goal(this@MainActivity))
        }
        col.addView(goalField)

        col.addView(button("1. Allow floating bubble") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(button("2. Open accessibility settings") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("3. Start assistant") { start() })
        col.addView(button("Stop assistant") {
            startService(Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_STOP))
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val overlay = Settings.canDrawOverlays(this)
        val a11y = GestureService.instance != null
        status.text = "Floating bubble permission: ${if (overlay) "OK" else "missing"}\n" +
            "Accessibility service: ${if (a11y) "ON" else "OFF"}"
    }

    private fun start() {
        Prefs.save(this, keyField.text.toString(), goalField.text.toString())
        when {
            Prefs.apiKey(this).isEmpty() -> toast("Enter your Gemini API key")
            !Settings.canDrawOverlays(this) -> toast("Step 1 first: allow the floating bubble")
            GestureService.instance == null -> toast("Step 2 first: turn on the GridAssist accessibility service")
            else -> {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
