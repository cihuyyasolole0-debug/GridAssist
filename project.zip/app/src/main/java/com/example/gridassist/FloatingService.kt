package com.example.gridassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.IntentCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Foreground service: floating bubble + MediaProjection.
 * Tap bubble = ONE assisted step (capture -> Gemini -> gestures). Long-press (~1s) = quit.
 */
class FloatingService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var projection: MediaProjection? = null
    private var capturer: ScreenCapturer? = null
    private var screenW = 0
    private var screenH = 0
    private var busy = false
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY

        // Android 14+: must be foreground (type mediaProjection) BEFORE getMediaProjection().
        startAsForeground()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (code != android.app.Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = realSize()
        screenW = size.first
        screenH = size.second

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        // Android 14+: callback must be registered before createVirtualDisplay().
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopping) stopSelf()
            }
        }, Handler(Looper.getMainLooper()))
        projection = mp
        capturer = ScreenCapturer(mp, screenW, screenH, resources.displayMetrics.densityDpi)

        addBubble()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "GridAssist", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("GridAssist is running")
            .setContentText("Tap the floating bubble for one assisted move")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "Stop", stop)
            .build()
        startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun realSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    // ---------------------------------------------------------------- bubble UI

    private val baseFlags =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun addBubble() {
        val size = (76 * resources.displayMetrics.density).toInt() // big target
        val tv = TextView(this).apply {
            text = "AI"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "Assist bubble. Tap for one assisted move. Hold to quit."
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC1565C0"))
                setStroke(4, Color.WHITE)
            }
        }
        bubbleParams = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 400
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop * 2 // tolerant of tremor
        tv.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0; var startY = 0
            var downRawX = 0f; var downRawY = 0f
            var moved = false
            var downTime = 0L
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = bubbleParams.x; startY = bubbleParams.y
                        downRawX = e.rawX; downRawY = e.rawY
                        moved = false; downTime = e.eventTime
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - downRawX).toInt()
                        val dy = (e.rawY - downRawY).toInt()
                        if (abs(dx) > slop || abs(dy) > slop) moved = true
                        if (moved) {
                            bubbleParams.x = startX + dx
                            bubbleParams.y = startY + dy
                            wm.updateViewLayout(v, bubbleParams)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        if (e.eventTime - downTime >= 1000) stopSelf() else onBubbleTapped()
                    }
                }
                return true
            }
        })
        wm.addView(tv, bubbleParams)
        bubble = tv
    }

    /** Invisible + untouchable while capturing and while gestures run. */
    private fun setBubbleVisible(visible: Boolean) {
        val tv = bubble ?: return
        tv.alpha = if (visible) 1f else 0f
        bubbleParams.flags = if (visible) baseFlags else baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(tv, bubbleParams)
    }

    private fun toast(msg: String) = Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()

    // ---------------------------------------------------------------- one assisted step

    private fun onBubbleTapped() {
        if (busy) return
        val gestures = GestureService.instance
        if (gestures == null) {
            toast("Turn on the GridAssist accessibility service first")
            return
        }
        val key = Prefs.apiKey(this)
        if (key.isEmpty()) {
            toast("Add your Gemini API key in the GridAssist app")
            return
        }
        val cap = capturer ?: return
        busy = true
        scope.launch {
            try {
                setBubbleVisible(false)
                delay(300) // let the screen redraw without the bubble
                val b64 = withContext(Dispatchers.Default) { cap.captureJpegBase64() }
                setBubbleVisible(true)
                if (b64 == null) {
                    toast("Could not capture the screen")
                    return@launch
                }
                bubble?.text = "…"
                val plan = GeminiClient.analyze(key, b64, Prefs.goal(this@FloatingService))
                if (plan.actions.isEmpty()) {
                    toast(plan.explanation.ifEmpty { "No move suggested" })
                    return@launch
                }
                setBubbleVisible(false)
                for (a in plan.actions.take(4)) {
                    val px = (a.x / 1000f * screenW).coerceIn(1f, screenW - 1f)
                    val py = (a.y / 1000f * screenH).coerceIn(1f, screenH - 1f)
                    when (a.type) {
                        "swipe" -> {
                            val px2 = (a.x2 / 1000f * screenW).coerceIn(1f, screenW - 1f)
                            val py2 = (a.y2 / 1000f * screenH).coerceIn(1f, screenH - 1f)
                            gestures.swipe(px, py, px2, py2)
                        }
                        else -> gestures.tap(px, py)
                    }
                    delay(500)
                }
                setBubbleVisible(true)
                if (plan.explanation.isNotEmpty()) toast(plan.explanation)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("Error: ${e.message?.take(150)}")
            } finally {
                bubble?.text = "AI"
                setBubbleVisible(true)
                busy = false
            }
        }
    }

    override fun onDestroy() {
        stopping = true
        scope.cancel()
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        capturer?.release()
        capturer = null
        projection?.stop()
        projection = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.example.gridassist.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "gridassist"
        private const val NOTIF_ID = 1
    }
}
