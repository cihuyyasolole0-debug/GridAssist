package com.example.gridassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.IntentCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Bubble tap = one step. Mode "suggest": show numbered markers only.
 * Mode "auto": markers are replaced by real gestures via GestureService.
 * Long-press bubble (~1s) = quit.
 */
class FloatingService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var bubbleBg: GradientDrawable? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var projection: MediaProjection? = null
    private var capturer: ScreenCapturer? = null
    private var screenW = 0
    private var screenH = 0
    private var busy = false
    private var stopping = false
    private val markers = mutableListOf<View>()
    private var markersJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent.action == ACTION_TOGGLE || intent.action == ACTION_REFRESH) {
            if (projection == null) {
                stopSelf()
                return START_NOT_STICKY
            }
            if (intent.action == ACTION_TOGGLE) {
                val next = if (Prefs.mode(this) == Prefs.MODE_AUTO) Prefs.MODE_SUGGEST else Prefs.MODE_AUTO
                Prefs.setMode(this, next)
            }
            refreshModeUi()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY

        startAsForeground()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (code != android.app.Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = realSize()
        screenW = size.first
        screenH = size.second

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(code, data)
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopping) stopSelf()
            }
        }, Handler(Looper.getMainLooper()))
        projection = mp
        capturer = ScreenCapturer(mp, screenW, screenH, resources.displayMetrics.densityDpi)

        addBubble()
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------ notification

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val auto = Prefs.mode(this) == Prefs.MODE_AUTO
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val toggle = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("GridAssist aktif")
            .setContentText(
                if (auto) "Mode Auto: langkah dijalankan otomatis"
                else "Mode Saran: hanya menampilkan petunjuk"
            )
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_rotate, "Ganti mode", toggle)
            .addAction(android.R.drawable.ic_delete, "Stop", stop)
            .build()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "GridAssist", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun refreshModeUi() {
        applyBubbleLook()
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        val auto = Prefs.mode(this) == Prefs.MODE_AUTO
        toast(if (auto) "Mode Auto: langkah dijalankan otomatis" else "Mode Saran: hanya petunjuk")
    }

    private fun realSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    // ------------------------------------------------------------ bubble

    private val baseFlags =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun applyBubbleLook() {
        val tv = bubble ?: return
        val auto = Prefs.mode(this) == Prefs.MODE_AUTO
        tv.text = if (auto) "⚡" else "💡"
        bubbleBg?.setColor(Color.parseColor(if (auto) "#E6EA580C" else "#E61D4ED8"))
    }

    private fun addBubble() {
        val size = (76 * resources.displayMetrics.density).toInt()
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#E61D4ED8"))
            setStroke(5, Color.WHITE)
        }
        bubbleBg = bg
        val tv = TextView(this).apply {
            textSize = 28f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "Tombol asisten. Ketuk untuk satu langkah. Tahan untuk keluar."
            background = bg
        }
        bubbleParams = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 400
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop * 2
        tv.setOnTouchListener(object : View.OnTouchListener {
            var startX = 0; var startY = 0
            var downRawX = 0f; var downRawY = 0f
            var moved = false
            var downTime = 0L
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = bubbleParams.x; startY = bubbleParams.y
                        downRawX = e.rawX; downRawY = e.rawY
                        moved = false; downTime = e.eventTime
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - downRawX).toInt()
                        val dy = (e.rawY - downRawY).toInt()
                        if (abs(dx) > slop || abs(dy) > slop) moved = true
                        if (moved) {
                            bubbleParams.x = startX + dx
                            bubbleParams.y = startY + dy
                            wm.updateViewLayout(v, bubbleParams)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        if (e.eventTime - downTime >= 1000) stopSelf() else onBubbleTapped()
                    }
                }
                return true
            }
        })
        wm.addView(tv, bubbleParams)
        bubble = tv
        applyBubbleLook()
    }

    private fun setBubbleVisible(visible: Boolean) {
        val tv = bubble ?: return
        tv.alpha = if (visible) 1f else 0f
        bubbleParams.flags = if (visible) baseFlags else baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(tv, bubbleParams)
    }

    private fun toast(msg: String) = Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------ markers (suggest mode)

    private fun px(nx: Int) = (nx / 1000f * screenW).coerceIn(1f, screenW - 1f)
    private fun py(ny: Int) = (ny / 1000f * screenH).coerceIn(1f, screenH - 1f)

    private fun addMarker(label: String, cx: Float, cy: Float, color: String) {
        val d = (58 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = label
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(color))
                setStroke(5, Color.WHITE)
            }
        }
        val lp = WindowManager.LayoutParams(
            d, d,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (cx - d / 2f).toInt()
            y = (cy - d / 2f).toInt()
        }
        wm.addView(tv, lp)
        markers.add(tv)
    }

    private fun showMarkers(actions: List<GeminiClient.Action>) {
        actions.take(4).forEachIndexed { i, a ->
            if (a.type == "swipe") {
                addMarker("${i + 1}a", px(a.x), py(a.y), "#D97706")
                addMarker("${i + 1}b", px(a.x2), py(a.y2), "#16A34A")
            } else {
                addMarker("${i + 1}", px(a.x), py(a.y), if (i == 0) "#D97706" else "#16A34A")
            }
        }
        markersJob?.cancel()
        markersJob = scope.launch {
            delay(10_000)
            removeMarkers()
        }
    }

    private fun removeMarkers() {
        markers.forEach { v -> runCatching { wm.removeView(v) } }
        markers.clear()
    }

    private fun clearMarkers() {
        markersJob?.cancel()
        removeMarkers()
    }

    // ------------------------------------------------------------ one assisted step

    private fun describe(actions: List<GeminiClient.Action>): String =
        actions.mapIndexed { i, a ->
            if (a.type == "swipe") "${i + 1}. swipe (${a.x},${a.y}) → (${a.x2},${a.y2})"
            else "${i + 1}. tap (${a.x},${a.y})"
        }.joinToString("\n")

    private fun onBubbleTapped() {
        if (busy) return
        val auto = Prefs.mode(this) == Prefs.MODE_AUTO
        val gestures = GestureService.instance
        if (auto && gestures == null) {
            toast("Mode Auto butuh layanan aksesibilitas GridAssist yang aktif")
            return
        }
        val key = Prefs.apiKey(this)
        if (key.isEmpty()) {
            toast("Isi Gemini API key di app GridAssist")
            return
        }
        val cap = capturer ?: return
        busy = true
        scope.launch {
            var jpeg: ByteArray? = null
            var status = "Dibatalkan"
            var explanation = ""
            var moves = ""
            var raw = ""
            try {
                clearMarkers()
                setBubbleVisible(false)
                delay(300)
                val b64 = withContext(Dispatchers.Default) { cap.captureJpegBase64() }
                setBubbleVisible(true)
                if (b64 == null) {
                    status = "Capture gagal"
                    toast("Gagal capture layar")
                    return@launch
                }
                jpeg = Base64.decode(b64, Base64.NO_WRAP)
                bubble?.text = "…"
                GeminiClient.lastRaw = ""
                val plan = GeminiClient.analyze(key, b64, Prefs.goal(this@FloatingService))
                raw = GeminiClient.lastRaw.take(1500)
                explanation = plan.explanation
                moves = describe(plan.actions)
                if (plan.actions.isEmpty()) {
                    status = "Tidak ada langkah"
                    toast(explanation.ifEmpty { "Tidak ada langkah yang disarankan" })
                    return@launch
                }
                if (auto && gestures != null) {
                    setBubbleVisible(false)
                    for (a in plan.actions.take(4)) {
                        when (a.type) {
                            "swipe" -> gestures.swipe(px(a.x), py(a.y), px(a.x2), py(a.y2))
                            else -> gestures.tap(px(a.x), py(a.y))
                        }
                        delay(500)
                    }
                    setBubbleVisible(true)
                    status = "Dijalankan"
                } else {
                    showMarkers(plan.actions)
                    status = "Disarankan"
                }
                if (explanation.isNotEmpty()) toast(explanation)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                raw = GeminiClient.lastRaw.take(1500)
                status = "Error: ${e.message?.take(120)}"
                toast(status)
            } finally {
                applyBubbleLook()
                setBubbleVisible(true)
                busy = false
                runCatching {
                    History.add(
                        applicationContext,
                        History.Entry(
                            System.currentTimeMillis(),
                            if (auto) Prefs.MODE_AUTO else Prefs.MODE_SUGGEST,
                            status, explanation, moves, null, raw
                        ),
                        jpeg
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        stopping = true
        scope.cancel()
        runCatching { removeMarkers() }
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        capturer?.release()
        capturer = null
        projection?.stop()
        projection = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.example.gridassist.STOP"
        const val ACTION_TOGGLE = "com.example.gridassist.TOGGLE"
        const val ACTION_REFRESH = "com.example.gridassist.REFRESH"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "gridassist"
        private const val NOTIF_ID = 1
    }
}
